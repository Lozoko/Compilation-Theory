import scanner
import ply.yacc as yacc

tokens = scanner.tokens

precedence = (
   ("left", '+', '-'),
   ("left", '*', '/')



)

def p_error(p):
    if p:
        print("Syntax error at line {0}: LexToken({1}, '{2}')".format(p.lineno, p.type, p.value))
    else:
        print("Unexpected end of input")


# dict for ids
IDs = {}
# var for return
return_value = None


def p_start(p):
    """start : LINE"""
    pass

def p_line(p):
    """LINE : IDX
            | IDXMATRIX
            | IFX
            | WHILEX
            | FORX
            | RETURNX
            | PRINTX
            | BLOCK
            | EMPTY"""
    p[0] = p[1]

def p_notemptyline(p):
    """NOTEMPTYLINE : IDX
                    | IDXMATRIX
                    | IFX
                    | WHILEX
                    | FORX
                    | RETURNX
                    | PRINTX"""
    p[0] = p[1]



def p_block(p):
    """BLOCK : '{' LINE '}' """
    p[0] = p[2]

def p_empty(p):
    """EMPTY :"""
    pass

#idx
def p_idx_assign(p):
    """IDX : ID '=' EXPRESSION ';' LINE
           | ID '=' ZEROSX ';' LINE
           | ID '=' ONESX ';' LINE
           | ID '=' EYEX ';' LINE
           | ID '=' MATRIX ';' LINE
           | ID '=' MATRIXEXPR ';' LINE"""
    IDs[p[1]] = p[3]

def p_idx_opassign(p):
    """IDX : ID ADDASSIGN EXPRESSION ';' LINE
           | ID SUBASSIGN EXPRESSION ';' LINE
           | ID MULASSIGN EXPRESSION ';' LINE
           | ID DIVASSIGN EXPRESSION ';' LINE"""
    if p[2] == "ADDASSIGN": IDs[p[1]] += p[3]
    elif p[2] == "SUBASSIGN": IDs[p[1]] -= p[3]
    elif p[2] == "MULASSIGN": IDs[p[1]] *= p[3]
    elif p[2] == "DIVASSIGN": IDs[p[1]] /= p[3]



#idxmatrix
def p_idxmatrix_assign(p):
    """IDXMATRIX : ID '[' EXPRESSION ',' EXPRESSION ']' '=' EXPRESSION ';' LINE"""
    # IDs[p[1]][p[3]][p[5]]= p[8]
    pass

def p_zerosx(p):
    """ZEROSX : ZEROS '(' EXPRESSION ')'"""
    p[0] = zeros(p[3])

def p_onesx(p):
    """ONESX : ONES '(' EXPRESSION ')'"""
    p[0] = ones(p[3])

def p_eyex(p):
    """EYEX : EYE '(' EXPRESSION ')'"""
    p[0] = eye(p[3])

def p_matrix(p):
    """MATRIX : '[' MATRIXINSIDE
              | MATRIX "'" """
    pass

def p_matrixinside(p):
    """MATRIXINSIDE : ROWS MATRIXINSIDE
                    | ROWS"""
    pass

def p_rows(p):
    """ROWS : '[' ROW ']' ','
            | '[' ROW ']' ']' """
    pass

def p_row(p):
    """ROW :  EXPRESSION ',' ROW
            | EXPRESSION"""
    pass

def zeros(dim):
    return [[0 for _ in range(dim)] for _ in range(dim)]

def ones(dim):
    return [[1 for _ in range(dim)] for _ in range(dim)]

def eye(dim):
    return [[1 if x==y else 0 for x in range(dim)]for y in range(dim)]


def p_matrixop(p):
    """MATRIXEXPR : ID DOTADD ID
               | ID DOTSUB ID
               | ID DOTMUL ID
               | ID DOTDIV ID
               | ID "'" """

    pass



def p_ifx_if(p):
    """IFX : IF '(' CONDITION ')' NOTEMPTYLINE ELSEX
           | IF '(' CONDITION ')' '{' LINE '}' ELSEX LINE """
    pass

def p_elsex(p):
    """ ELSEX : ELSE NOTEMPTYLINE
              | ELSE '{' LINE '}' LINE
              | EMPTY"""

def p_loopline(p):
    """LOOPLINE : IDX
                | IDXMATRIX
                | WHILEX
                | FORX
                | RETURNX
                | PRINTX
                | BLOCK
                | EMPTY
                | LOOPIFX
                | BREAK ';' LOOPLINE
                | CONTINUE ';' LOOPLINE"""
    p[0] = p[1]

def p_notemptyloopline(p):
    """NOTEMPTYLOOPLINE : IDX
                        | IDXMATRIX
                        | WHILEX
                        | FORX
                        | RETURNX
                        | PRINTX
                        | LOOPIFX
                        | BREAK ';' LOOPLINE
                        | CONTINUE ';' LOOPLINE"""
    p[0] = p[1]

def p_loopifx_if(p):
    """LOOPIFX : IF '(' CONDITION ')' NOTEMPTYLOOPLINE LOOPELSEX
           | IF '(' CONDITION ')' '{' LOOPLINE '}' LOOPELSEX LOOPLINE """
    pass

def p_loopelsex(p):
    """ LOOPELSEX : ELSE NOTEMPTYLOOPLINE
              | ELSE '{' LOOPLINE '}' LOOPLINE
              | EMPTY"""

#WHILE
def p_whilex(p):
    """WHILEX : WHILE '(' CONDITION ')' NOTEMPTYLOOPLINE
           | WHILE '(' CONDITION ')' '{' LOOPLINE '}'  LINE """
    pass

#FOR
def p_forx(p):
    """FORX : FOR ID '=' EXPRESSION ':' EXPRESSION NOTEMPTYLOOPLINE
               | FOR ID '=' EXPRESSION ':' EXPRESSION '{' LOOPLINE  '}' LINE """
    pass


#CONDITION
def p_condition(p):
    """CONDITION : EXPRESSION EQUAL EXPRESSION
                    | EXPRESSION UNEQUAL EXPRESSION
                    | EXPRESSION LESSEQUAL EXPRESSION
                    | EXPRESSION GREATEREQUAL EXPRESSION
                    | EXPRESSION '>' EXPRESSION
                    | EXPRESSION '<' EXPRESSION """

    pass

#PRINT
def p_printx(p):
    """PRINTX : PRINT PRINTMANY ';' LINE """

def p_printmany(p):
    """PRINTMANY :  STRING
                |  EXPRESSION
                | PRINTMANY ',' PRINTMANY"""
#return
def p_returnx_return(p):
    """RETURNX : RETURN EXPRESSION ';' LINE"""
    global return_value
    return_value = p[2]

#expression
def p_expression_number(p):
    """EXPRESSION : NUMBER"""
    p[0] = p[1]

def p_expression_float(p):
    """EXPRESSION : FLOATNUMBER"""
    p[0] = p[1]

def p_expression_id(p):
    """EXPRESSION : ID"""
    p[0] = p[1]

def p_expression_sum(p):
    """EXPRESSION : EXPRESSION '+' EXPRESSION
                  | EXPRESSION '-' EXPRESSION"""

    pass


def p_expression_mul(p):
    """EXPRESSION : EXPRESSION '*' EXPRESSION
                  | EXPRESSION '/' EXPRESSION"""

    pass


def p_expression_group(p):
    """EXPRESSION : '(' EXPRESSION ')'"""
    p[0] = p[2]

def p_expression_unarynegation(p):
    """EXPRESSION : '-' EXPRESSION"""
    pass


parser = yacc.yacc()